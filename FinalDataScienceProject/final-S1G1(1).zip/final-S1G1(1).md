
# Final Exam: Part B

* Section: Sec01

* Group Number: S1G1: Mercedes Bischoff, Ryan Mandel, Bryce Owen, Kimberly Tang

* Due Date: May 7, 2020

* Purpose: Culmination of Semester Knowledge Base

## Preprocessing data


```python
#--Load Libraries 
import pandas as pd
import seaborn as sns
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn import metrics
```


```python
#--Import and Preview Data Set
plants = pd.read_excel('http://barney.gonzaga.edu/~chuang/data/plants.xlsx')
plants.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>sepal_length</th>
      <th>sepal_width</th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>species</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>4.3</td>
      <td>2.8</td>
      <td>1.9</td>
      <td>NaN</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>4.8</td>
      <td>3.4</td>
      <td>1.6</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>5.0</td>
      <td>3.0</td>
      <td>1.8</td>
      <td>0.4</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>4.8</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>5.1</td>
      <td>3.8</td>
      <td>1.6</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#--Identify Missing Data
plants.isnull().sum()
```




    ID               0
    sepal_length     1
    sepal_width      5
    petal_length    10
    petal_width      8
    species          0
    dtype: int64




```python
#--Identify records that have missing values
plants[plants.isnull().any(axis=1)]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>sepal_length</th>
      <th>sepal_width</th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>species</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>4.3</td>
      <td>2.8</td>
      <td>1.9</td>
      <td>NaN</td>
      <td>0</td>
    </tr>
    <tr>
      <th>32</th>
      <td>33</td>
      <td>5.4</td>
      <td>2.9</td>
      <td>1.7</td>
      <td>NaN</td>
      <td>0</td>
    </tr>
    <tr>
      <th>35</th>
      <td>36</td>
      <td>5.7</td>
      <td>3.6</td>
      <td>NaN</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>38</th>
      <td>39</td>
      <td>5.3</td>
      <td>NaN</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>39</th>
      <td>40</td>
      <td>4.7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
    </tr>
    <tr>
      <th>46</th>
      <td>47</td>
      <td>4.6</td>
      <td>3.0</td>
      <td>NaN</td>
      <td>0.5</td>
      <td>0</td>
    </tr>
    <tr>
      <th>62</th>
      <td>63</td>
      <td>NaN</td>
      <td>3.1</td>
      <td>1.8</td>
      <td>0.3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>67</th>
      <td>68</td>
      <td>5.2</td>
      <td>3.8</td>
      <td>NaN</td>
      <td>0.4</td>
      <td>0</td>
    </tr>
    <tr>
      <th>102</th>
      <td>103</td>
      <td>5.2</td>
      <td>2.7</td>
      <td>NaN</td>
      <td>0.5</td>
      <td>0</td>
    </tr>
    <tr>
      <th>115</th>
      <td>116</td>
      <td>5.5</td>
      <td>2.4</td>
      <td>3.7</td>
      <td>NaN</td>
      <td>1</td>
    </tr>
    <tr>
      <th>142</th>
      <td>143</td>
      <td>5.1</td>
      <td>NaN</td>
      <td>4.4</td>
      <td>1.6</td>
      <td>1</td>
    </tr>
    <tr>
      <th>166</th>
      <td>167</td>
      <td>5.3</td>
      <td>3.0</td>
      <td>NaN</td>
      <td>1.8</td>
      <td>1</td>
    </tr>
    <tr>
      <th>191</th>
      <td>192</td>
      <td>4.9</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>199</th>
      <td>200</td>
      <td>5.8</td>
      <td>2.7</td>
      <td>4.1</td>
      <td>NaN</td>
      <td>1</td>
    </tr>
    <tr>
      <th>228</th>
      <td>229</td>
      <td>5.8</td>
      <td>2.4</td>
      <td>NaN</td>
      <td>2.1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>239</th>
      <td>240</td>
      <td>5.8</td>
      <td>NaN</td>
      <td>5.1</td>
      <td>1.9</td>
      <td>2</td>
    </tr>
    <tr>
      <th>262</th>
      <td>263</td>
      <td>5.9</td>
      <td>3.6</td>
      <td>NaN</td>
      <td>1.5</td>
      <td>2</td>
    </tr>
    <tr>
      <th>266</th>
      <td>267</td>
      <td>6.4</td>
      <td>3.2</td>
      <td>6.3</td>
      <td>NaN</td>
      <td>2</td>
    </tr>
    <tr>
      <th>297</th>
      <td>298</td>
      <td>5.7</td>
      <td>2.5</td>
      <td>5.0</td>
      <td>NaN</td>
      <td>2</td>
    </tr>
    <tr>
      <th>316</th>
      <td>317</td>
      <td>7.3</td>
      <td>2.9</td>
      <td>NaN</td>
      <td>1.8</td>
      <td>2</td>
    </tr>
    <tr>
      <th>323</th>
      <td>324</td>
      <td>7.6</td>
      <td>2.4</td>
      <td>6.8</td>
      <td>NaN</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Fill all missing data with averages grouped by species
plants['sepal_length'] = plants['sepal_length'].fillna(plants.groupby('species')['sepal_length'].transform('mean'))
plants['sepal_width'] = plants['sepal_width'].fillna(plants.groupby('species')['sepal_width'].transform('mean'))
plants['petal_length'] = plants['petal_length'].fillna(plants.groupby('species')['petal_length'].transform('mean'))
plants['petal_width'] = plants['petal_width'].fillna(plants.groupby('species')['petal_width'].transform('mean'))
plants.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>sepal_length</th>
      <th>sepal_width</th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>species</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>4.3</td>
      <td>2.8</td>
      <td>1.9</td>
      <td>0.299057</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>4.8</td>
      <td>3.4</td>
      <td>1.6</td>
      <td>0.200000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>5.0</td>
      <td>3.0</td>
      <td>1.8</td>
      <td>0.400000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>4.8</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.300000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>5.1</td>
      <td>3.8</td>
      <td>1.6</td>
      <td>0.200000</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#-- Standardize numeric variable by adding zscore columns
plants['sepal_length_z'] = stats.zscore(plants['sepal_length'], nan_policy = 'omit')
plants['sepal_width_z'] = stats.zscore(plants['sepal_width'], nan_policy = 'omit')
plants['petal_length_z'] = stats.zscore(plants['petal_length'], nan_policy = 'omit')
plants['petal_width_z'] = stats.zscore(plants['petal_width'], nan_policy = 'omit')

plants.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>sepal_length</th>
      <th>sepal_width</th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>species</th>
      <th>sepal_length_z</th>
      <th>sepal_width_z</th>
      <th>petal_length_z</th>
      <th>petal_width_z</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>4.3</td>
      <td>2.8</td>
      <td>1.9</td>
      <td>0.299057</td>
      <td>0</td>
      <td>-1.679790</td>
      <td>-0.436789</td>
      <td>-1.034591</td>
      <td>-1.234960</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>4.8</td>
      <td>3.4</td>
      <td>1.6</td>
      <td>0.200000</td>
      <td>0</td>
      <td>-1.121177</td>
      <td>0.703984</td>
      <td>-1.201071</td>
      <td>-1.365184</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>5.0</td>
      <td>3.0</td>
      <td>1.8</td>
      <td>0.400000</td>
      <td>0</td>
      <td>-0.897731</td>
      <td>-0.056531</td>
      <td>-1.090085</td>
      <td>-1.102255</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>4.8</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.300000</td>
      <td>0</td>
      <td>-1.121177</td>
      <td>-0.056531</td>
      <td>-1.312058</td>
      <td>-1.233719</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>5.1</td>
      <td>3.8</td>
      <td>1.6</td>
      <td>0.200000</td>
      <td>0</td>
      <td>-0.786009</td>
      <td>1.464498</td>
      <td>-1.201071</td>
      <td>-1.365184</td>
    </tr>
  </tbody>
</table>
</div>




```python
#--Identify rows with zscores >3 or <-3
plants[(plants['sepal_length_z'] > 3) | 
        (plants['sepal_length_z'] < -3) |
        (plants['sepal_width_z'] > 3) | 
        (plants['sepal_width_z'] < -3) |
        (plants['petal_length_z'] > 3) | 
        (plants['petal_length_z'] < -3) |  
        (plants['petal_width_z'] > 3) | 
        (plants['petal_width_z'] < -3)]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>sepal_length</th>
      <th>sepal_width</th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>species</th>
      <th>sepal_length_z</th>
      <th>sepal_width_z</th>
      <th>petal_length_z</th>
      <th>petal_width_z</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>106</th>
      <td>107</td>
      <td>4.800000</td>
      <td>5.020648</td>
      <td>1.8</td>
      <td>0.200000</td>
      <td>0</td>
      <td>-1.121177</td>
      <td>3.785301</td>
      <td>-1.090085</td>
      <td>-1.365184</td>
    </tr>
    <tr>
      <th>116</th>
      <td>117</td>
      <td>8.900000</td>
      <td>2.600000</td>
      <td>3.3</td>
      <td>1.300000</td>
      <td>1</td>
      <td>3.459455</td>
      <td>-0.817046</td>
      <td>-0.257685</td>
      <td>0.080925</td>
    </tr>
    <tr>
      <th>154</th>
      <td>155</td>
      <td>8.975003</td>
      <td>2.900000</td>
      <td>4.9</td>
      <td>1.500000</td>
      <td>1</td>
      <td>3.543250</td>
      <td>-0.246660</td>
      <td>0.630209</td>
      <td>0.343854</td>
    </tr>
    <tr>
      <th>216</th>
      <td>217</td>
      <td>7.000000</td>
      <td>4.974328</td>
      <td>5.1</td>
      <td>1.800000</td>
      <td>1</td>
      <td>1.336723</td>
      <td>3.697233</td>
      <td>0.741195</td>
      <td>0.738247</td>
    </tr>
    <tr>
      <th>261</th>
      <td>262</td>
      <td>9.157097</td>
      <td>3.300000</td>
      <td>5.2</td>
      <td>2.400000</td>
      <td>2</td>
      <td>3.746691</td>
      <td>0.513855</td>
      <td>0.796688</td>
      <td>1.527034</td>
    </tr>
    <tr>
      <th>282</th>
      <td>283</td>
      <td>8.975003</td>
      <td>3.800000</td>
      <td>6.7</td>
      <td>2.200000</td>
      <td>2</td>
      <td>3.543250</td>
      <td>1.464498</td>
      <td>1.629088</td>
      <td>1.264105</td>
    </tr>
    <tr>
      <th>294</th>
      <td>295</td>
      <td>6.700000</td>
      <td>2.700000</td>
      <td>5.0</td>
      <td>4.052461</td>
      <td>2</td>
      <td>1.001555</td>
      <td>-0.626917</td>
      <td>0.685702</td>
      <td>3.699432</td>
    </tr>
  </tbody>
</table>
</div>




```python
#--Drop rows that conatin outliers
plants = plants.drop(plants[(plants['sepal_length_z'] > 3) | 
        (plants['sepal_length_z'] < -3) |
        (plants['sepal_width_z'] > 3) | 
        (plants['sepal_width_z'] < -3) |
        (plants['petal_length_z'] > 3) | 
        (plants['petal_length_z'] < -3) |  
        (plants['petal_width_z'] > 3) | 
        (plants['petal_width_z'] < -3)].index)
plants.shape
```




    (319, 10)




```python
#Find duplicate records
plants[plants.duplicated(subset=plants.columns.difference(['ID']))]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>sepal_length</th>
      <th>sepal_width</th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>species</th>
      <th>sepal_length_z</th>
      <th>sepal_width_z</th>
      <th>petal_length_z</th>
      <th>petal_width_z</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>54</th>
      <td>55</td>
      <td>4.9</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.1</td>
      <td>0</td>
      <td>-1.009454</td>
      <td>0.133597</td>
      <td>-1.256565</td>
      <td>-1.496648</td>
    </tr>
    <tr>
      <th>91</th>
      <td>92</td>
      <td>4.9</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.1</td>
      <td>0</td>
      <td>-1.009454</td>
      <td>0.133597</td>
      <td>-1.256565</td>
      <td>-1.496648</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Drop those records
plants.drop_duplicates(subset=plants.columns.difference(['ID']), inplace = True)
plants.shape
```




    (317, 10)




```python
#--Add Species Name Column to Data Set
def Species(x):
    if x == 0:
        return "setosa"
    elif x == 1:
        return "versicolor"
    else:
        return "virginica"

plants['SpeciesName'] = plants['species'].apply(Species)
plants.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>sepal_length</th>
      <th>sepal_width</th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>species</th>
      <th>sepal_length_z</th>
      <th>sepal_width_z</th>
      <th>petal_length_z</th>
      <th>petal_width_z</th>
      <th>SpeciesName</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>4.3</td>
      <td>2.8</td>
      <td>1.9</td>
      <td>0.299057</td>
      <td>0</td>
      <td>-1.679790</td>
      <td>-0.436789</td>
      <td>-1.034591</td>
      <td>-1.234960</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>4.8</td>
      <td>3.4</td>
      <td>1.6</td>
      <td>0.200000</td>
      <td>0</td>
      <td>-1.121177</td>
      <td>0.703984</td>
      <td>-1.201071</td>
      <td>-1.365184</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>5.0</td>
      <td>3.0</td>
      <td>1.8</td>
      <td>0.400000</td>
      <td>0</td>
      <td>-0.897731</td>
      <td>-0.056531</td>
      <td>-1.090085</td>
      <td>-1.102255</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>4.8</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.300000</td>
      <td>0</td>
      <td>-1.121177</td>
      <td>-0.056531</td>
      <td>-1.312058</td>
      <td>-1.233719</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>5.1</td>
      <td>3.8</td>
      <td>1.6</td>
      <td>0.200000</td>
      <td>0</td>
      <td>-0.786009</td>
      <td>1.464498</td>
      <td>-1.201071</td>
      <td>-1.365184</td>
      <td>setosa</td>
    </tr>
  </tbody>
</table>
</div>



## Explore Dataset


```python
#--Histogram of Each Variable (Z score variables not needed because they are the same distribution as normal variables)
plants[['petal_length','petal_width','sepal_length','sepal_width','species']].hist(bins=10,figsize=(20,15))
plt.show()
```


![png](output_14_0.png)



```python
#--Correlation Chart (Z score variables not needed because they are the same distribution as normal variables)
plants[['petal_length','petal_width','sepal_length','sepal_width','species']].corr().style.background_gradient("Greens")
```




<style  type="text/css" >
    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow0_col0 {
            background-color:  #00441b;
            color:  #f1f1f1;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow0_col1 {
            background-color:  #005321;
            color:  #f1f1f1;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow0_col2 {
            background-color:  #238b45;
            color:  #000000;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow0_col3 {
            background-color:  #f7fcf5;
            color:  #000000;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow0_col4 {
            background-color:  #005020;
            color:  #f1f1f1;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow1_col0 {
            background-color:  #005321;
            color:  #f1f1f1;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow1_col1 {
            background-color:  #00441b;
            color:  #f1f1f1;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow1_col2 {
            background-color:  #289049;
            color:  #000000;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow1_col3 {
            background-color:  #f5fbf2;
            color:  #000000;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow1_col4 {
            background-color:  #005221;
            color:  #f1f1f1;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow2_col0 {
            background-color:  #1a843f;
            color:  #000000;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow2_col1 {
            background-color:  #208843;
            color:  #000000;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow2_col2 {
            background-color:  #00441b;
            color:  #f1f1f1;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow2_col3 {
            background-color:  #e4f5df;
            color:  #000000;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow2_col4 {
            background-color:  #218944;
            color:  #000000;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow3_col0 {
            background-color:  #f7fcf5;
            color:  #000000;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow3_col1 {
            background-color:  #f7fcf5;
            color:  #000000;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow3_col2 {
            background-color:  #f7fcf5;
            color:  #000000;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow3_col3 {
            background-color:  #00441b;
            color:  #f1f1f1;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow3_col4 {
            background-color:  #f7fcf5;
            color:  #000000;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow4_col0 {
            background-color:  #005020;
            color:  #f1f1f1;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow4_col1 {
            background-color:  #005221;
            color:  #f1f1f1;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow4_col2 {
            background-color:  #2a924a;
            color:  #000000;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow4_col3 {
            background-color:  #f6fcf4;
            color:  #000000;
        }    #T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow4_col4 {
            background-color:  #00441b;
            color:  #f1f1f1;
        }</style><table id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4f" ><thead>    <tr>        <th class="blank level0" ></th>        <th class="col_heading level0 col0" >petal_length</th>        <th class="col_heading level0 col1" >petal_width</th>        <th class="col_heading level0 col2" >sepal_length</th>        <th class="col_heading level0 col3" >sepal_width</th>        <th class="col_heading level0 col4" >species</th>    </tr></thead><tbody>
                <tr>
                        <th id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4flevel0_row0" class="row_heading level0 row0" >petal_length</th>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow0_col0" class="data row0 col0" >1</td>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow0_col1" class="data row0 col1" >0.933236</td>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow0_col2" class="data row0 col2" >0.706361</td>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow0_col3" class="data row0 col3" >-0.337176</td>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow0_col4" class="data row0 col4" >0.950746</td>
            </tr>
            <tr>
                        <th id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4flevel0_row1" class="row_heading level0 row1" >petal_width</th>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow1_col0" class="data row1 col0" >0.933236</td>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow1_col1" class="data row1 col1" >1</td>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow1_col2" class="data row1 col2" >0.686138</td>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow1_col3" class="data row1 col3" >-0.314986</td>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow1_col4" class="data row1 col4" >0.939716</td>
            </tr>
            <tr>
                        <th id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4flevel0_row2" class="row_heading level0 row2" >sepal_length</th>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow2_col0" class="data row2 col0" >0.706361</td>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow2_col1" class="data row2 col1" >0.686138</td>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow2_col2" class="data row2 col2" >1</td>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow2_col3" class="data row2 col3" >-0.160228</td>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow2_col4" class="data row2 col4" >0.676827</td>
            </tr>
            <tr>
                        <th id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4flevel0_row3" class="row_heading level0 row3" >sepal_width</th>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow3_col0" class="data row3 col0" >-0.337176</td>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow3_col1" class="data row3 col1" >-0.314986</td>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow3_col2" class="data row3 col2" >-0.160228</td>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow3_col3" class="data row3 col3" >1</td>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow3_col4" class="data row3 col4" >-0.323291</td>
            </tr>
            <tr>
                        <th id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4flevel0_row4" class="row_heading level0 row4" >species</th>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow4_col0" class="data row4 col0" >0.950746</td>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow4_col1" class="data row4 col1" >0.939716</td>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow4_col2" class="data row4 col2" >0.676827</td>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow4_col3" class="data row4 col3" >-0.323291</td>
                        <td id="T_2957ea1a_8fe5_11ea_9296_f45c89c00f4frow4_col4" class="data row4 col4" >1</td>
            </tr>
    </tbody></table>



## Clustering


```python
#Choose variabes to cluster and justify choice
# We chose to select the two variables with the strongest correlation to species, petal_length and petal_width

X = plants[['petal_length', 'petal_width']]
X.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>petal_length</th>
      <th>petal_width</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.9</td>
      <td>0.299057</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.6</td>
      <td>0.200000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.8</td>
      <td>0.400000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.4</td>
      <td>0.300000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1.6</td>
      <td>0.200000</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Plot the distribution of sepal_length and petal_length
plt.figure(figsize=(8,6))
sns.scatterplot(X['petal_length'], X['petal_width'])
```




    <matplotlib.axes._subplots.AxesSubplot at 0x12b632048>




![png](output_18_1.png)



```python
#Save means and standard deviations
#Used to standardize data of new plants for prediction
plants_mean = X.mean()
plants_std = X.std()
print(plants_mean)
print()
print(plants_std)
```

    petal_length    3.760817
    petal_width     1.230537
    dtype: float64
    
    petal_length    1.804528
    petal_width     0.742804
    dtype: float64



```python
#Standardize the data
z_score = stats.zscore(X)
X_z = pd.DataFrame(z_score, columns = ['petal_length_z', 'petal_width_z'])
X_z.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>petal_length_z</th>
      <th>petal_width_z</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>312</th>
      <td>1.686861</td>
      <td>1.576880</td>
    </tr>
    <tr>
      <th>313</th>
      <td>0.687793</td>
      <td>0.363339</td>
    </tr>
    <tr>
      <th>314</th>
      <td>1.686861</td>
      <td>1.085716</td>
    </tr>
    <tr>
      <th>315</th>
      <td>0.965312</td>
      <td>0.767852</td>
    </tr>
    <tr>
      <th>316</th>
      <td>0.743297</td>
      <td>1.576880</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Fit a model with the data
#Create three clusters
from sklearn.cluster import KMeans

kmeans_plants = KMeans(n_clusters = 3).fit(X_z)
```


```python
#Obtain the labels
cluster = kmeans_plants.labels_
cluster
```




    array([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
           1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
           1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
           1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
           1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2,
           2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
           2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
           2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
           2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
           2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0, 2, 0, 0,
           0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0,
           2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 0, 2, 2, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0,
           0, 0, 0, 0, 0, 2, 0, 0, 0], dtype=int32)




```python
#Obtain the centroids
cluster_center = kmeans_plants.cluster_centers_
cluster_center
```




    array([[ 1.11418969,  1.12703719],
           [-1.27561714, -1.24966339],
           [ 0.27487366,  0.24182267]])




```python
X_z.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>petal_length_z</th>
      <th>petal_width_z</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>312</th>
      <td>1.686861</td>
      <td>1.576880</td>
    </tr>
    <tr>
      <th>313</th>
      <td>0.687793</td>
      <td>0.363339</td>
    </tr>
    <tr>
      <th>314</th>
      <td>1.686861</td>
      <td>1.085716</td>
    </tr>
    <tr>
      <th>315</th>
      <td>0.965312</td>
      <td>0.767852</td>
    </tr>
    <tr>
      <th>316</th>
      <td>0.743297</td>
      <td>1.576880</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Merge original data, rescaled data and add column to label the results of clustering
clt = pd.DataFrame(cluster, columns=['cluster'])
plants_cluster = X.merge(X_z, on = X.index)
plants_cluster = pd.concat([plants_cluster, clt], axis = 1, sort = True)
plants_cluster = plants_cluster.rename(columns={'key_0': 'ID'})
plants_cluster.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>petal_length_z</th>
      <th>petal_width_z</th>
      <th>cluster</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>312</th>
      <td>321</td>
      <td>6.8</td>
      <td>2.400000</td>
      <td>1.686861</td>
      <td>1.576880</td>
      <td>0</td>
    </tr>
    <tr>
      <th>313</th>
      <td>322</td>
      <td>5.0</td>
      <td>1.500000</td>
      <td>0.687793</td>
      <td>0.363339</td>
      <td>2</td>
    </tr>
    <tr>
      <th>314</th>
      <td>323</td>
      <td>6.8</td>
      <td>2.035738</td>
      <td>1.686861</td>
      <td>1.085716</td>
      <td>0</td>
    </tr>
    <tr>
      <th>315</th>
      <td>324</td>
      <td>5.5</td>
      <td>1.800000</td>
      <td>0.965312</td>
      <td>0.767852</td>
      <td>0</td>
    </tr>
    <tr>
      <th>316</th>
      <td>325</td>
      <td>5.1</td>
      <td>2.400000</td>
      <td>0.743297</td>
      <td>1.576880</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Preview the new dataset
plants_cluster.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>petal_length_z</th>
      <th>petal_width_z</th>
      <th>cluster</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>1.9</td>
      <td>0.299057</td>
      <td>-1.032823</td>
      <td>-1.255988</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>1.6</td>
      <td>0.200000</td>
      <td>-1.199335</td>
      <td>-1.389553</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>1.8</td>
      <td>0.400000</td>
      <td>-1.088327</td>
      <td>-1.119878</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>1.4</td>
      <td>0.300000</td>
      <td>-1.310342</td>
      <td>-1.254716</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>1.6</td>
      <td>0.200000</td>
      <td>-1.199335</td>
      <td>-1.389553</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Plot clusters
plt.figure(figsize=(8,6))
sns.scatterplot(plants_cluster['petal_length_z'],
                plants_cluster['petal_width_z'],
                hue=plants_cluster['cluster'])

#Plot centroids of the clusters
plt.plot(cluster_center[:,0],
         cluster_center[:,1],
         'r*',
         markersize=10)
# Centroids marked with stars
```




    [<matplotlib.lines.Line2D at 0x12ba565f8>]




![png](output_27_1.png)



```python
#Predict plants
#Suppose we have 5 plants and they have the following measurements
#The data is saved in a list, each element of which has two values: width and length
plant_list = [[4.5, 2.3],
            [2.92, 1.5],
             [1.2, 0.3],
             [1.2, 0.5],
             [4.9, 2]]
#Convert the list to a dataframe
newplant = pd.DataFrame(plant_list,columns=['petal_length','petal_width'])
newplant
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>petal_length</th>
      <th>petal_width</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4.50</td>
      <td>2.3</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2.92</td>
      <td>1.5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.20</td>
      <td>0.3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.20</td>
      <td>0.5</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4.90</td>
      <td>2.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Standardize the measurements of new plants
newplant_z = (newplant-plants_mean)/plants_std
newplant_z = newplant_z.rename(columns={'petal_length': 'petal_length_z', 'petal_width': 'petal_width_z'})
newplant_z
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>petal_length_z</th>
      <th>petal_width_z</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.409627</td>
      <td>1.439765</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-0.465948</td>
      <td>0.362765</td>
    </tr>
    <tr>
      <th>2</th>
      <td>-1.419106</td>
      <td>-1.252735</td>
    </tr>
    <tr>
      <th>3</th>
      <td>-1.419106</td>
      <td>-0.983485</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.631291</td>
      <td>1.035890</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Prediction
preds = kmeans_plants.predict(newplant_z)
preds
```




    array([0, 2, 1, 1, 0], dtype=int32)




```python
#Interpretations
#The first plant belongs to the cluster of high petal_length and petal_width
#The second plant belongs to the cluster of medium petal_length and petal_width
#The thrid plant belongs to the cluster of low petal_length and petal_width
#The fourth plant belongs to the cluster of low petal_length and petal_width
#The fifth plant belongs to the cluster of high petal_length and petal_width

# Combine original data, standardized data and predicted clusters
combined_newplant = pd.concat([newplant, newplant_z, pd.DataFrame(preds, columns=['cluster'])], axis = 1)
combined_newplant
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>petal_length_z</th>
      <th>petal_width_z</th>
      <th>cluster</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4.50</td>
      <td>2.3</td>
      <td>0.409627</td>
      <td>1.439765</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2.92</td>
      <td>1.5</td>
      <td>-0.465948</td>
      <td>0.362765</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.20</td>
      <td>0.3</td>
      <td>-1.419106</td>
      <td>-1.252735</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.20</td>
      <td>0.5</td>
      <td>-1.419106</td>
      <td>-0.983485</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4.90</td>
      <td>2.0</td>
      <td>0.631291</td>
      <td>1.035890</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Plot clusters
plt.figure(figsize=(8,6))
sns.scatterplot(plants_cluster['petal_length_z'],
                plants_cluster['petal_width_z'],
                hue=plants_cluster['cluster'])

#Plot centroids of the clusters
plt.plot(cluster_center[:,0],
         cluster_center[:,1],
         'r*',
         markersize=10)

#Plot predictions
plt.plot(newplant_z.iloc[:,0],
         newplant_z.iloc[:,1],
         'go',
         markersize=10)

# Graph shows where predicted flowers should lie with green dots
```




    [<matplotlib.lines.Line2D at 0x12b4e27b8>]




![png](output_32_1.png)


## Classification


```python
#--Preview Data and drop non-predictors
plants.drop(['ID','sepal_length_z','sepal_width_z','petal_length_z','petal_width_z','SpeciesName'], axis = 1, inplace = True)
plants.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal_length</th>
      <th>sepal_width</th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>species</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4.3</td>
      <td>2.8</td>
      <td>1.9</td>
      <td>0.299057</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.8</td>
      <td>3.4</td>
      <td>1.6</td>
      <td>0.200000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>5.0</td>
      <td>3.0</td>
      <td>1.8</td>
      <td>0.400000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.8</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.300000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.1</td>
      <td>3.8</td>
      <td>1.6</td>
      <td>0.200000</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# establish predictors
outcome = 'species'
predictors = [c for c in plants.columns if c != outcome]
predictors
```




    ['sepal_length', 'sepal_width', 'petal_length', 'petal_width']




```python
# --Split training and testing
# Test size of 30% used which is around the industry standard
X = plants.drop('species',axis=1) # -- features --
y = plants['species']             # -- target --

x_train, x_test, y_train, y_test = train_test_split(X,y,
                                                    test_size = 0.3, 
                                                    random_state=1)

```


```python
# -- train neural nets and fit model--
# Solver type is lbfgs
# Hidden layer sizes is 3
ann_clf = MLPClassifier(hidden_layer_sizes = (3), 
                        activation = 'logistic', 
                        solver = 'lbfgs', random_state = 1)

ann_clf.fit(x_train,y_train)
```




    MLPClassifier(activation='logistic', alpha=0.0001, batch_size='auto',
                  beta_1=0.9, beta_2=0.999, early_stopping=False, epsilon=1e-08,
                  hidden_layer_sizes=3, learning_rate='constant',
                  learning_rate_init=0.001, max_iter=200, momentum=0.9,
                  n_iter_no_change=10, nesterovs_momentum=True, power_t=0.5,
                  random_state=1, shuffle=True, solver='lbfgs', tol=0.0001,
                  validation_fraction=0.1, verbose=False, warm_start=False)




```python
# -- confusion matrix --

metrics.confusion_matrix(y_true = y_train, 
                         y_pred = ann_clf.predict(x_train))
```




    array([[76,  0,  0],
           [ 0, 68,  1],
           [ 0,  2, 74]])




```python
# -- Use sklearn.metrics to present confustion_matrix --

# -- use seaborn heatmapt to present the confusion matrix --
# -- This is based on TRAINING DATA --
%matplotlib inline

sns.heatmap(metrics.confusion_matrix(y_true = y_train, 
                                     y_pred = ann_clf.predict(x_train)),
                                    annot=True,
                                    cbar=False,
                                    fmt='g',
                                    cmap = plt.cm.get_cmap('Blues'))
plt.ylabel('Actual')
plt.xlabel('Predicted')
```




    Text(0.5, 16.0, 'Predicted')




![png](output_39_1.png)



```python
# -- Validation performance --
# -- Use test data --
metrics.confusion_matrix(y_true = y_test,
                         y_pred=ann_clf.predict(x_test))
```




    array([[30,  0,  0],
           [ 0, 35,  2],
           [ 0,  2, 27]])




```python
# --- Print Confusion Matrix Using Panda's crosstab function ---
sns.set_style('white')
print('--- Confusion Matrix (predict on rows, actual on columns ---')
cmtab = metrics.confusion_matrix(y_test,ann_clf.predict(x_test))

# confusion_matrix = pd.crosstab(preds, y_test,rownames=['Predicted'], colnames=['Actual'])
ax = sns.heatmap(cmtab, annot=True,fmt='g',cbar=False,cmap='Blues')
ax.set(xlabel="Predicted",ylabel="Actual");

# The confusion matrix shows that nearly all of the predicted values were correctly identified. There were 2 flowers 
# in classes 1 and 2 were misidentified. This is very minimal in the grand scheme of the dataset
```

    --- Confusion Matrix (predict on rows, actual on columns ---



![png](output_41_1.png)



```python
# show metrics
print(metrics.classification_report(y_true = y_test, 
                                    y_pred = ann_clf.predict(x_test)))

# The model has high performance in all areas. Especially the accuracy, precision, and F1 score which are 
# good metrics for this model because our biggest concern is classifying flowers correctly and avoiding false positives 
```

                  precision    recall  f1-score   support
    
               0       1.00      1.00      1.00        30
               1       0.95      0.95      0.95        37
               2       0.93      0.93      0.93        29
    
        accuracy                           0.96        96
       macro avg       0.96      0.96      0.96        96
    weighted avg       0.96      0.96      0.96        96
    

